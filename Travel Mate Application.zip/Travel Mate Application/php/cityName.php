 <?php
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'travel');
	
	$conn = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);

	if(mysqli_connect_errno()){
		die('connection failed. '.mysqli_connect_error());
	}

	$query = "SELECT Name, Day FROM cityname;";
	$sql = $conn->prepare($query);
	$sql->execute();

	$sql->bind_result($Name, $Day);

	$cityPlacesDetails = array();
	
	while ($sql->fetch()) {
		$placeDetails = array();

		$placeDetails['Name'] = $Name;
		$placeDetails['Day'] = $Day;
		array_push($cityPlacesDetails,$placeDetails);
	}
	
	echo json_encode($cityPlacesDetails);
?>