 <?php
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'travel');

	$cityName = filter_input(INPUT_POST, "cityName");
	$category = filter_input(INPUT_POST, "category");
	$conn = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);

	if(mysqli_connect_errno()){
		die('connection failed. '.mysqli_connect_error());
	}

	$query = "SELECT Name, Address, Phone, Rating, Image FROM $cityName where Category = '".$category."' ;";
	$sql = $conn->prepare($query);
	$sql->execute();

	$sql->bind_result($Name, $Address, $Phone, $Rating, $Image);

	$cityPlacesDetails = array();

	// echo '<img alt="aaaaaaaaaaaa" src="images/Airport.jpg">';
	
	while ($sql->fetch()) {
		$placeDetails = array();

		// Part A
		$placeDetails['Name'] = $Name;
		$placeDetails['Address'] = $Address;
		$placeDetails['Phone'] = $Phone;
		$placeDetails['Rating'] = $Rating;
		// $ImagePath = 'images/'.$Image.'';
		$placeDetails['Image'] = $Image;
		$placeDetails['City'] = $cityName;
	
		array_push($cityPlacesDetails,$placeDetails);
	}

	echo json_encode($cityPlacesDetails);

?>