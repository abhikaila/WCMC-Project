package com.example.dell.tmate;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class part1HomePage extends AppCompatActivity {

    String[] cityNameList = new String[part1EnterCityName.selectedCity.size()];
    RecyclerView mHomePageRV;
    String[] category = {"Park","Hotel","Bar","Cafe","Religious","Theatre","Shopping"};
    Spinner mList, mCategory;
    TextView dayTv;

    String cityname1="", category1="";
    List<placeDetailModel> placeList1;
    PlaceDetailAdapter adapter1;

    public static final String URL = "http://localhost/travelGuide/placeData.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.part1_home_page);

        dayTv = findViewById(R.id.Days);
        mList = findViewById(R.id.sList);
        mCategory = findViewById(R.id.category);
        int i=0;
        for(String s : part1EnterCityName.selectedCity){
            cityNameList[i] = s;
            i++;
        }
        final HashMap<String, Integer> hash_map = new HashMap<String, Integer>();
        hash_map.put("ahmedabad",3);
        hash_map.put("vadodara",2);
        hash_map.put("mumbai",5);
        hash_map.put("nasik",2);
        hash_map.put("mahabaleshwar",3);
        hash_map.put("shirdi",1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.spinner_item,cityNameList);
        mList.setAdapter(adapter);

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<String>(this,R.layout.spinner_item,category);
        mCategory.setAdapter(categoryAdapter);

        mList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                cityname1 = mList.getSelectedItem().toString();
                dayTv.setText("Days Required :       "+hash_map.get(cityname1));
                if(category1!=""){
                    placeList1.clear();
                    LoadData();
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
                return;
            }
        });

        mCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                category1 = mCategory.getSelectedItem().toString();
                if(cityname1!=""){
                    placeList1.clear();
                    LoadData();
                }
                }

            public void onNothingSelected(AdapterView<?> adapterView) {
                return;
            }
        });


        placeList1 = new ArrayList<>();

        mHomePageRV = findViewById(R.id.homePageRV);
        mHomePageRV.setHasFixedSize(true);
        mHomePageRV.setLayoutManager(new LinearLayoutManager(this));

        LoadData();

    }

    private void LoadData() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            JSONArray places = new JSONArray(response);


                            for (int i=0;i<places.length();i++){
                                JSONObject placesObject = places.getJSONObject(i);


                                float Ratings= placesObject.getInt("Rating");
                                String Name = placesObject.getString("Name");
                                String Address = placesObject.getString("Address");
                                String Phone = placesObject.getString("Phone");
                                String Image = placesObject.getString("Image");
                                String city = placesObject.getString("City");

                                placeDetailModel placeDetailModel=new placeDetailModel(Ratings, Name, Address, Phone, Image ,city);
                                placeList1.add(placeDetailModel);

                            }

                            adapter1 = new PlaceDetailAdapter(part1HomePage.this,placeList1);
                            mHomePageRV.setAdapter(adapter1);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("cityName", cityname1);
                params.put("category", category1);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
