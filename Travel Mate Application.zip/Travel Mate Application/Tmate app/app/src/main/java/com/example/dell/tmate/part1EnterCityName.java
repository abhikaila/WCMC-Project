package com.example.dell.tmate;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class part1EnterCityName extends AppCompatActivity {

    EditText mSourceNameEditText, mDestinationEditText;
    Spinner mSourceSpinner, mDestinationSpinner;
    Button mSubmitBtn;

    private boolean mSpinnerInitialized;

    String[] cityList = {"ahmedabad","vadodara","mumbai","nasik","mahabaleshwar","shirdi"};

    public static final Set<String> selectedCity = new HashSet<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.part1_enter_city_name);

        mDestinationSpinner = findViewById(R.id.DestinationList);
        mSourceSpinner = findViewById(R.id.SourceList);
        mSubmitBtn = findViewById(R.id.submitBtn);

        LinearLayout ll = (LinearLayout) findViewById(R.id.ll);

        final CheckBox[] cb = new CheckBox[cityList.length];
        for (int i = 0; i < cityList.length; i++) {
            cb[i] = new CheckBox(this);
            ll.addView(cb[i]);
            cb[i].setText(cityList[i]);
            cb[i].setId(i);
        }


        assignSourceSpinner();
        assignDestinationSpinner();

        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mDestinationSpinner.getSelectedItem().toString()!="Select Destination" &&
                        mSourceSpinner.getSelectedItem().toString()!="Select Source") {
                    selectedCity.clear();
                    selectedCity.add(mDestinationSpinner.getSelectedItem().toString());
                    selectedCity.add(mSourceSpinner.getSelectedItem().toString());
                    for (int i = 0; i < cityList.length; i++) {
                        if (cb[i].isChecked()) {
                            selectedCity.add(cb[i].getText().toString());
                        }
                    }

                    Intent intent = new Intent(part1EnterCityName.this, part1HomePage.class);

                    startActivity(intent);
                } else {
                    Toast.makeText(part1EnterCityName.this, "Please Select City Name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void assignDestinationSpinner() {
        String[] formList={"Select Destination","ahmedabad","vadodara","mumbai","nasik","mahabaleshwar","shirdi"};
        String source;
        try {
            source = mSourceSpinner.getSelectedItem().toString();
        }catch (Exception e){
            source = "";
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.spinner_item,formList);

        if(!source.equals("Select Source")) {
            adapter.remove(source);
            mSourceSpinner.setAdapter(adapter);
        }
        mDestinationSpinner.setAdapter(adapter);
    }


    private void assignSourceSpinner() {
        String[] formList={"Select Source","ahmedabad","vadodara","mumbai","nasik","mahabaleshwar","shirdi"};
        String destination;
        try {
            destination = mDestinationSpinner.getSelectedItem().toString();
        }catch (Exception e){
            destination = "";
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.spinner_item,formList);
        if(!destination.equals("Select Destination")) {
            adapter.remove(destination);
            mDestinationSpinner.setAdapter(adapter);
        }
        mSourceSpinner.setAdapter(adapter);
    }
}
