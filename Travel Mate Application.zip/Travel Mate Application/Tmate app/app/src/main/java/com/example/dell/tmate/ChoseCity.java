package com.example.dell.tmate;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChoseCity extends AppCompatActivity {
//    SearchView mChoseCitySearchView;
//    ListView mCityNameViewList;
    RecyclerView mCityNameRecyclerView;
    List<cityModel> cityList;
    cityAdapter adapter;

    public static final String URL = "http://localhost/travelGuide/cityName.php";

//    ArrayList<String> CityNameList;
//    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chose_city);

        cityList = new ArrayList<>();

        mCityNameRecyclerView = findViewById(R.id.cityNameRecyclerView);
        mCityNameRecyclerView.setHasFixedSize(true);
        mCityNameRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadCity();
    }

    private void loadCity() {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONArray places = new JSONArray(response);

                                for (int i=0;i<places.length();i++){
                                    JSONObject placesObject = places.getJSONObject(i);

                                    String Name = placesObject.getString("Name");

                                    cityModel citymodel =new cityModel(Name);
                                    cityList.add(citymodel);

                                }

                                adapter = new cityAdapter(ChoseCity.this,cityList);
                                mCityNameRecyclerView.setAdapter(adapter);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    });
            Volley.newRequestQueue(this).add(stringRequest);
    }

//--------------------------------------------------------------------------------------------------
    class cityModel{
        String Name;

        public cityModel(String name) {
            Name = name;
        }

        public String getName() {
            return Name;
        }

        public void setName(String name) {
            Name = name;
        }
    }
//--------------------------------------------------------------------------------------------------
    class cityAdapter extends RecyclerView.Adapter<cityAdapter.UserViewHolder> implements Filterable {
        private Context context;
        private List<cityModel> cityList;
        private List<cityModel> cityFullList;

        public cityAdapter(Context context, List<cityModel> cityList) {
            this.context = context;
            this.cityList = cityList;
            cityFullList = new ArrayList<>(cityList);
        }

        @NonNull
        @Override
        public cityAdapter.UserViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.chose_city_custom, null);
            UserViewHolder holder = new UserViewHolder(view);
            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull cityAdapter.UserViewHolder holder, int i) {
            final cityModel user= cityList.get(i);

            holder.mCityName.setText(user.getName());
            holder.mCityName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ChoseCity.this, categoryDetails.class);
//                    mChoseCitySearchView.setQuery(user.getName(),true);
//                    mCityNameRecyclerView.setVisibility(View.INVISIBLE);
                    intent.putExtra("cityName",user.getName());
                    context.startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return cityList.size();
        }

    @Override
    public Filter getFilter() {
        return cityFilter;
    }

    private Filter cityFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<cityModel> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(cityFullList);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (cityModel item : cityFullList) {
                    if (item.getName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            cityList.clear();
            cityList.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };

    class UserViewHolder extends RecyclerView.ViewHolder {
            TextView mCityName;
            public UserViewHolder(@NonNull View itemView) {
                super(itemView);

                mCityName = itemView.findViewById(R.id.cityName);
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_page_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.homePageSearchBar);
        android.support.v7.widget.SearchView searchView = (android.support.v7.widget.SearchView) searchItem.getActionView();

        searchView.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });

        return true;
    }
}
