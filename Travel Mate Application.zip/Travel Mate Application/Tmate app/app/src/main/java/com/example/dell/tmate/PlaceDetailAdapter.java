package com.example.dell.tmate;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

public class PlaceDetailAdapter extends RecyclerView.Adapter<PlaceDetailAdapter.UserViewHolder> {

    private Context context;
    private List<placeDetailModel> placesList;

    public PlaceDetailAdapter(Context context, List<placeDetailModel> placesList) {
        this.context = context;
        this.placesList = placesList;
    }

    @NonNull
    @Override
    public PlaceDetailAdapter.UserViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.place_details_custom, null);
        UserViewHolder holder = new UserViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final PlaceDetailAdapter.UserViewHolder holder, final int i) {
        final placeDetailModel user= placesList.get(i);

        holder.mName.setText(user.getName());
        holder.mAddress.setText(user.getAddress());
        holder.mPhone.setText(user.getPhone());
        holder.mRatings.setText(String.valueOf(user.getRating()));
        final String ImageURL = "http://localhost/travelGuide/images/"+user.getCity()+"/"+user.getImage();
        Picasso.get().load(ImageURL).fit().into(holder.mPlaceImage);
        holder.mplaceDetailsRelativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(holder.mAddressLinearLayout.getVisibility() == View.VISIBLE){
                    holder.mAddressLinearLayout.setVisibility(View.GONE);
                    holder.mPhoneLinearLayout.setVisibility(View.GONE);
                }else {
                    holder.mAddressLinearLayout.setVisibility(View.VISIBLE);
                    holder.mPhoneLinearLayout.setVisibility(View.VISIBLE);
                }
            }
        });
        holder.mMapIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Address = user.getName()+"+"+user.getAddress();
//                String s =  "Civil Aerodrome, Harni Rd, Vadodara, Gujarat 390022";
                Address = Address.replace(" ","+");
                Uri gmmIntentUri = Uri.parse("google.navigation:q= "+Address);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                context.startActivity(mapIntent);
            }

        });

    }

    @Override
    public int getItemCount() {
        return placesList.size();
    }

    class UserViewHolder extends RecyclerView.ViewHolder{

        TextView mName, mAddress, mPhone, mRatings;
        RelativeLayout mplaceDetailsRelativeLayout;
        LinearLayout mPhoneLinearLayout, mAddressLinearLayout;
        ImageView mMapIcon, mPlaceImage;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            mName = itemView.findViewById(R.id.Name);
            mAddress = itemView.findViewById(R.id.Address);
            mPhone = itemView.findViewById(R.id.Phone);
            mRatings = itemView.findViewById(R.id.Rating);
            mplaceDetailsRelativeLayout = itemView.findViewById(R.id.placeDetailsRelativeLayout);
            mPhoneLinearLayout = itemView.findViewById(R.id.phoneLinearLayout);
            mAddressLinearLayout = itemView.findViewById(R.id.AddressLinearLayout);
            mMapIcon = itemView.findViewById(R.id.mapIcon);
            mPlaceImage = itemView.findViewById(R.id.placeImageView);
        }
    }
}
