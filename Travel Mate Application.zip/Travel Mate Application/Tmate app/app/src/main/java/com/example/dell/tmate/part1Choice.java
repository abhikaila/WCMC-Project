package com.example.dell.tmate;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class part1Choice extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.part1_choice);
    }
}
