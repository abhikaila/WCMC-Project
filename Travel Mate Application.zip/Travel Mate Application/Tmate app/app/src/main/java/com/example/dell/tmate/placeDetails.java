package com.example.dell.tmate;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class placeDetails extends AppCompatActivity {

    public static String cityName;
    RecyclerView mplaceDetailRecyclerView;
    List<placeDetailModel> placeList;
    PlaceDetailAdapter adapter;
    TextView mcity,mcategory;
    public static final String URL = "http:/localhost/travelGuide/placeData.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.place_details);

        placeList = new ArrayList<>();

        mplaceDetailRecyclerView = findViewById(R.id.placeDetailsRecyclerView);
        mplaceDetailRecyclerView.setHasFixedSize(true);
        mplaceDetailRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mcity = findViewById(R.id.nameplace);
        mcategory = findViewById(R.id.categoryplaces);

        mcity.setText("City : "+getIntent().getExtras().get("cityName").toString());
        mcategory.setText("Category : "+getIntent().getExtras().get("category").toString());
        loadUsers();
    }

    private void loadUsers() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONArray places = new JSONArray(response);

                            for (int i=0;i<places.length();i++){
                                JSONObject placesObject = places.getJSONObject(i);


                                float Ratings= placesObject.getInt("Rating");
                                String Name = placesObject.getString("Name");
                                String Address = placesObject.getString("Address");
                                String Phone = placesObject.getString("Phone");
                                String Image = placesObject.getString("Image");
                                String City = placesObject.getString("City");

                                placeDetailModel placeDetailModel=new placeDetailModel(Ratings, Name, Address, Phone, Image, City);
                                placeList.add(placeDetailModel);

                            }

                            adapter = new PlaceDetailAdapter(placeDetails.this,placeList);
                            mplaceDetailRecyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                cityName = getIntent().getExtras().get("cityName").toString();
                String category = getIntent().getExtras().get("category").toString();
                params.put("cityName", cityName);
                params.put("category", category);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

}
