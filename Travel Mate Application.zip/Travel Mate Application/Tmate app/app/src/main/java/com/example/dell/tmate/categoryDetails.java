package com.example.dell.tmate;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.support.v7.widget.SearchView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class categoryDetails extends AppCompatActivity {

    public static String city;
    RecyclerView mCategoryRecyclerView;
    List<categoryModel> categoryList;
    categoryAdapter adapter;

    public static final String URL = "http://Localhost/travelGuide/categoryDetails.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.category_details);

        city = getIntent().getExtras().get("cityName").toString();

        categoryList = new ArrayList<>();

        mCategoryRecyclerView = findViewById(R.id.categoryRecyclerView);
        mCategoryRecyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 2);
        mCategoryRecyclerView.setLayoutManager(mLayoutManager);

        loadCategory();
    }

    private void loadCategory() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONArray places = new JSONArray(response);

                            for (int i=0;i<places.length();i++){
                                JSONObject placesObject = places.getJSONObject(i);

                                String Name = placesObject.getString("Name");
                                String Image = placesObject.getString("Image");

                                categoryModel categorymodel=new categoryModel(Name, Image);
                                categoryList.add(categorymodel);
                            }
                            adapter = new categoryAdapter(categoryDetails.this,categoryList);
                            mCategoryRecyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        Volley.newRequestQueue(this).add(stringRequest);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_page_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.homePageSearchBar);
        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });

        return true;
    }
}
