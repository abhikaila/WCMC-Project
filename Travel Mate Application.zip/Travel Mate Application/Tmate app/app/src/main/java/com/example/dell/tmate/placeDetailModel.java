package com.example.dell.tmate;

public class placeDetailModel {
    float Rating;
    String name, Address, Phone, Image ,City;


    public placeDetailModel(float rating, String name, String address, String phone, String image, String city) {

        Rating = rating;
        this.name = name;
        Address = address;
        Phone = phone;
        Image = image;
        City = city;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public float getRating() {
        return Rating;
    }

    public void setRating(float rating) {
        Rating = rating;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }
}
