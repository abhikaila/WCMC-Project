package com.example.dell.tmate;

public class part1HomePageAdapter {

}
