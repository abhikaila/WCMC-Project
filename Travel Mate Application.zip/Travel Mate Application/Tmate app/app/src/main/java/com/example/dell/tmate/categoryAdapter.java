package com.example.dell.tmate;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class categoryAdapter extends RecyclerView.Adapter<categoryAdapter.UserViewHolder> implements Filterable {
    private Context context;
    private List<categoryModel> categoryList;
    private List<categoryModel> categoryFullList;

    public categoryAdapter(Context context, List<categoryModel> categoryList) {
        this.context = context;
        this.categoryList = categoryList;
        categoryFullList = new ArrayList<>(categoryList);
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.category_details_custom, null);
        UserViewHolder holder = new UserViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int i) {
        final categoryModel user = categoryList.get(i);

        holder.mCategoryName.setText(user.getName());

        final String ImageURL = "http://Localhost/travelGuide/images/category/"+user.getImage();
        Picasso.get().load(ImageURL).fit().into(holder.mCategoryImage);;

        holder.mCategoryRelativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cityName, category;
                cityName = categoryDetails.city;
                category = user.getName();

                Intent intent = new Intent(context, placeDetails.class);
                intent.putExtra("cityName", cityName);
                intent.putExtra("category", category);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    class UserViewHolder extends RecyclerView.ViewHolder{

        TextView mCategoryName;
        RelativeLayout mCategoryRelativeLayout;
        ImageView mCategoryImage;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            mCategoryName = itemView.findViewById(R.id.categoryName);
            mCategoryImage = itemView.findViewById(R.id.categoryImage);
            mCategoryRelativeLayout = itemView.findViewById(R.id.categoryRelativeLayout);
        }
    }


    @Override
    public Filter getFilter() {
        return categoryFilter;
    }

    private Filter categoryFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<categoryModel> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(categoryFullList);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (categoryModel item : categoryFullList) {
                    if (item.getName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            categoryList.clear();
            categoryList.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };
}
